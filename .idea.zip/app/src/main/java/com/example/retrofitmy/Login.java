package com.example.retrofitmy;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.renderscript.ScriptGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Login extends AppCompatActivity {

    @SuppressLint({"MissingInflatedId", "LocalSuppress"})

    private FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

         EditText editText = findViewById(R.id.login);

         mAuth = FirebaseAuth.getInstance();
         mAuth.createUserWithEmailAndPassword(editText.getText().toString(),"12345678").addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
             @Override
             public void onComplete(@NonNull Task<AuthResult> task) {
                 Toast.makeText(Login.this, "login", Toast.LENGTH_SHORT).show();
                 FirebaseUser user = mAuth.getCurrentUser();
             }
         });



    }
}

